#include<stdio.h>
#include<string.h>

int main()
{
        char line[300];
        int l;
        int n;
        printf("How many sentence you want to check...?\n");
        scanf("%d",&n);
        for(int i=0;i<n;i++)
            {
                 printf("Enter sentence....\n");
                 scanf("%d",&n);
                 gets(line);
                 l=strlen(line)-1;
                 char last=line[l];

                 if(last==';')
                 printf("valid\n");
                 else
                 printf("Error....Try Again\n");


        }

}
