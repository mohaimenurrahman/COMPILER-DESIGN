#include<stdio.h>
int main()
{
 int  j,f=1 ,n;
      printf("Enter a number: ");
      scanf("%d",&n);
    for(j=1;j<=n;j++){
      f=f*j;
  }
  printf("Factorial of %d is: %d",j,f);
return 0;
}
