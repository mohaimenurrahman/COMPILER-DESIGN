#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int top = -1;
char stack[50];
void push(char);
void pop();
void findtop();
void main()
{
	int i;
	char input[50];
	printf("Enter mathematical expression: ");
	scanf("%s", &input);
	for (i = 0; input[i] !=NULL; i++)
	{
		if (input[i] == '(')
		{
			push(input[i]);
		}
		else if (input[i] == ')')
		{
			pop();
		}
	}
	findtop();
}

void push(char input)
{
	stack[top] = input;
	top++;
}

void pop()
{
	if (top == -1)
	{
		printf("expression is invalid\n");
		exit(0);
	}
	else
	{
		top--;
	}
}

void findtop()
{
	if (top == -1)
		printf("Expression is valid and properly parenthesized\n");
	else
		printf("Expression is invalid and not properly parenthesized\n");
}
